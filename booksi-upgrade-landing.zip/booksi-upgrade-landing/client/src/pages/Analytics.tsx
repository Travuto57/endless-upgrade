import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart3, TrendingUp, Users, MousePointer } from "lucide-react";

interface AnalyticsEvent {
  event: string;
  properties: {
    resort_name?: string;
    resort_location?: string;
    survey_url?: string;
    timestamp: string;
    url: string;
  };
}

export default function Analytics() {
  const [events, setEvents] = useState<AnalyticsEvent[]>([]);
  const [stats, setStats] = useState({
    totalPageViews: 0,
    totalClicks: 0,
    clicksByResort: {} as Record<string, number>,
    scrollToResortsClicks: 0,
  });

  useEffect(() => {
    // In a real implementation, you would fetch from your analytics API
    // For now, we'll use localStorage to demonstrate
    const storedEvents = localStorage.getItem('analytics_events');
    if (storedEvents) {
      const parsedEvents: AnalyticsEvent[] = JSON.parse(storedEvents);
      setEvents(parsedEvents);

      // Calculate stats
      const pageViews = parsedEvents.filter(e => e.event === 'page_view').length;
      const resortClicks = parsedEvents.filter(e => e.event === 'resort_upgrade_click');
      const scrollClicks = parsedEvents.filter(e => e.event === 'scroll_to_resorts_click').length;

      const clicksByResort: Record<string, number> = {};
      resortClicks.forEach(event => {
        const resortName = event.properties.resort_name || 'Unknown';
        clicksByResort[resortName] = (clicksByResort[resortName] || 0) + 1;
      });

      setStats({
        totalPageViews: pageViews,
        totalClicks: resortClicks.length,
        clicksByResort,
        scrollToResortsClicks: scrollClicks,
      });
    }
  }, []);

  const conversionRate = stats.totalPageViews > 0 
    ? ((stats.totalClicks / stats.totalPageViews) * 100).toFixed(1)
    : '0.0';

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="container">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Analytics Dashboard</h1>
          <p className="text-muted-foreground">
            Track performance of your resort upgrade landing page
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Page Views</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalPageViews}</div>
              <p className="text-xs text-muted-foreground">Unique visitors</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Clicks</CardTitle>
              <MousePointer className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalClicks}</div>
              <p className="text-xs text-muted-foreground">Resort selections</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{conversionRate}%</div>
              <p className="text-xs text-muted-foreground">Click-through rate</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Scroll Clicks</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.scrollToResortsClicks}</div>
              <p className="text-xs text-muted-foreground">CTA button clicks</p>
            </CardContent>
          </Card>
        </div>

        {/* Resort Performance */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Resort Performance</CardTitle>
            <CardDescription>
              Number of clicks per resort option
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(stats.clicksByResort).length > 0 ? (
                Object.entries(stats.clicksByResort)
                  .sort(([, a], [, b]) => b - a)
                  .map(([resort, clicks]) => {
                    const percentage = stats.totalClicks > 0 
                      ? ((clicks / stats.totalClicks) * 100).toFixed(1)
                      : '0.0';
                    return (
                      <div key={resort} className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium">{resort}</span>
                            <Badge variant="secondary">{clicks} clicks</Badge>
                          </div>
                          <div className="w-full bg-muted rounded-full h-2">
                            <div
                              className="bg-primary h-2 rounded-full transition-all"
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                        <span className="ml-4 text-sm text-muted-foreground font-medium">
                          {percentage}%
                        </span>
                      </div>
                    );
                  })
              ) : (
                <p className="text-muted-foreground text-center py-8">
                  No data yet. Clicks will appear here once users interact with the page.
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Events */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Events</CardTitle>
            <CardDescription>
              Latest tracked user interactions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {events.length > 0 ? (
                events.slice(-10).reverse().map((event, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant={event.event === 'resort_upgrade_click' ? 'default' : 'secondary'}>
                          {event.event.replace(/_/g, ' ')}
                        </Badge>
                        {event.properties.resort_name && (
                          <span className="text-sm font-medium">{event.properties.resort_name}</span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {new Date(event.properties.timestamp).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground text-center py-8">
                  No events tracked yet.
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

