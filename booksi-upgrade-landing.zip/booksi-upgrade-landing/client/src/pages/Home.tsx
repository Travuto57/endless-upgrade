import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Star, MapPin, Sparkles } from "lucide-react";
import { Carousel } from "@/components/Carousel";
import { useEffect } from "react";
import { trackPageView, trackResortClick, trackScrollToResorts } from "@/lib/analytics";

const resorts = [
  {
    name: "Hyatt Vivid Grand Island",
    location: "Cancun, Mexico",
    surveyUrl: "https://access.booksi.com/hyatt-vivid-grand-island-survey-3",
    images: [
      "/hyatt_exterior.jpg",
      "/hyatt_vivid_3.webp",
      "/hyatt_vivid_4.webp",
      "/hyatt_vivid_1.webp"
    ],
    retailValue: "$2,999",
    highlights: [
      "400 modern all-suite accommodations",
      "11 dining venues & 6 bars",
      "3 pools with Caribbean views",
      "Adults-only luxury experience"
    ],
    description: "Brand new adults-only resort nestled between Nichupté Lagoon and the Caribbean Sea"
  },
  {
    name: "Dreams Los Cabos",
    location: "Cabo San Lucas, Mexico",
    surveyUrl: "https://access.booksi.com/ultra-luxury-cabo-resort-nm-survey-3",
    images: [
      "/dreams_exterior.jpg",
      "/dreams_cabos_4.jpg",
      "/dreams_cabos_2.jpg",
      "/dreams_cabos_1.jpg"
    ],
    retailValue: "$3,117",
    highlights: [
      "282 stunning suites",
      "AAA Four Diamond Resort",
      "8 championship golf courses nearby",
      "Colonial Mexican elegance"
    ],
    description: "Luxury resort on the Sea of Cortez with world-class spa and unlimited gourmet dining"
  },
  {
    name: "Secrets Vallarta Bay",
    location: "Puerto Vallarta, Mexico",
    surveyUrl: "https://access.booksi.com/ultra-adult-luxury-puerto-vallarta-survey-3",
    images: [
      "/secrets_exterior.jpg",
      "/secrets_vallarta_3.webp",
      "/secrets_vallarta_4.webp",
      "/secrets_vallarta_1.jpg"
    ],
    retailValue: "$2,849",
    highlights: [
      "271 spacious oceanfront suites",
      "7 international restaurants",
      "3 pools including private plunge pools",
      "Romantic beachfront setting"
    ],
    description: "Adults-only paradise on golden beaches along the Mexican Pacific coast"
  },
  {
    name: "Breathless Punta Cana",
    location: "Punta Cana, Dominican Republic",
    surveyUrl: "https://access.booksi.com/luxury-adult-punta-cana-survey-3",
    images: [
      "/breathless_exterior.jpg",
      "/breathless_punta_cana_2.jpg",
      "/breathless_punta_cana_3.jpg",
      "/breathless_punta_cana_1.jpg"
    ],
    retailValue: "$2,735",
    highlights: [
      "750 luxurious suites",
      "6 swimming pools & 2 hot tubs",
      "Vibrant, modern atmosphere",
      "Pristine Caribbean beachfront"
    ],
    description: "Chic all-inclusive resort offering the ultimate adults-only Caribbean escape"
  }
];

export default function Home() {
  // Track page view on mount
  useEffect(() => {
    trackPageView('upgrade_landing_page');
  }, []);

  const scrollToResorts = () => {
    trackScrollToResorts();
    const resortsSection = document.getElementById('resort-selection');
    if (resortsSection) {
      resortsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleUpgrade = (resortName: string, resortLocation: string, surveyUrl: string) => {
    trackResortClick(resortName, resortLocation, surveyUrl);
    window.location.href = surveyUrl;
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/10 via-background to-accent/10 py-16 md:py-24">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <Badge className="mb-4 text-base px-4 py-2" variant="secondary">
              <Sparkles className="w-4 h-4 mr-2 inline" />
              Exclusive Upgrade Offer
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
              Congratulations! You're Eligible for a{" "}
              <span className="text-primary">Premium Upgrade</span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
              Thank you for completing our survey! As a valued Booksi customer, upgrade your 5-night all-inclusive vacation to a luxury resort experience for only <span className="font-bold text-accent">$149 more</span>.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-6">
              <Button size="lg" className="text-lg px-8 py-6" onClick={scrollToResorts}>
                Upgrade My Vacation Now
              </Button>
              <p className="text-sm text-muted-foreground">
                Limited time offer • Instant confirmation
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Value Proposition */}
      <section className="py-8 md:py-12 bg-muted/30">
        <div className="container">
          <div className="max-w-5xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold">Your Current Package</h2>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <span>5 nights all-inclusive accommodation</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <span>Unlimited meals and drinks</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <span>Standard resort amenities</span>
                  </li>
                </ul>
              </div>
              <div className="space-y-4 bg-gradient-to-br from-primary/5 to-accent/5 p-8 rounded-xl border-2 border-primary/20">
                <Badge className="mb-2">Premium Upgrade</Badge>
                <h2 className="text-3xl font-bold">Upgrade to Luxury</h2>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-accent fill-accent mt-1 flex-shrink-0" />
                    <span className="font-semibold">Premium resort accommodations</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-accent fill-accent mt-1 flex-shrink-0" />
                    <span className="font-semibold">Multiple gourmet restaurants</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-accent fill-accent mt-1 flex-shrink-0" />
                    <span className="font-semibold">World-class spa facilities</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-accent fill-accent mt-1 flex-shrink-0" />
                    <span className="font-semibold">Enhanced amenities & service</span>
                  </li>
                </ul>
            <div className="pt-4 border-t border-primary/20">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground line-through">Regular Value: $2,735 - $3,117</p>
                <p className="text-3xl font-bold text-accent">Only $149 More</p>
                <p className="text-sm text-muted-foreground">One-time upgrade fee</p>
                <p className="text-lg font-semibold text-primary mt-2">Save up to $2,968!</p>
              </div>
            </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Resort Showcase */}
      <section id="resort-selection" className="py-12 md:py-16">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Choose Your Premium Destination
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Select from four stunning luxury resorts, each offering world-class amenities and unforgettable experiences. These premium packages typically retail between $2,735 and $3,117 per person.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {resorts.map((resort, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className="relative">
                  <Carousel images={resort.images} alt={resort.name} />
                  <div className="absolute top-4 right-4 z-10">
                    <Badge className="bg-accent text-accent-foreground">
                      Premium
                    </Badge>
                  </div>
                </div>
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex-1">
                      <CardTitle className="text-2xl">{resort.name}</CardTitle>
                      <CardDescription className="flex items-center gap-2 text-base mt-1">
                        <MapPin className="w-4 h-4" />
                        {resort.location}
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground line-through">{resort.retailValue}</p>
                      <p className="text-lg font-bold text-accent">$149</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">{resort.description}</p>
                  <ul className="space-y-2">
                    {resort.highlights.map((highlight, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm">
                        <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>{highlight}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className="w-full mt-4" 
                    size="lg"
                    onClick={() => handleUpgrade(resort.name, resort.location, resort.surveyUrl)}
                  >
                    Upgrade to This Resort
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-16 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold">
              Ready to Upgrade Your Experience?
            </h2>
            <p className="text-lg opacity-90">
              Don't miss this exclusive opportunity to elevate your vacation. Upgrade now and create memories that will last a lifetime.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
              <Button 
                size="lg" 
                variant="secondary" 
                className="text-lg px-8 py-6 bg-white text-primary hover:bg-white/90"
                onClick={scrollToResorts}
              >
                Upgrade for Only $149
              </Button>
            </div>
            <div className="pt-6 space-y-2 text-sm opacity-80">
              <p>✓ Instant confirmation</p>
              <p>✓ Same great dates and location</p>
              <p>✓ All-inclusive luxury experience</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t">
        <div className="container">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 Booksi. All rights reserved.</p>
            <p className="mt-2">Questions? Contact our support team for assistance.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

