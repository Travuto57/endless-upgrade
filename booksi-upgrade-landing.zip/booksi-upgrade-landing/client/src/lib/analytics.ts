// Analytics tracking utility
export const trackEvent = (eventName: string, properties?: Record<string, any>) => {
  // Send to analytics endpoint
  if (typeof window !== 'undefined') {
    // Track with console for debugging
    console.log('Analytics Event:', eventName, properties);
    
    // Send to your analytics service (e.g., Google Analytics, Mixpanel, etc.)
    // Example with Google Analytics 4
    if ((window as any).gtag) {
      (window as any).gtag('event', eventName, properties);
    }
    
    // Store events in localStorage for demo (in production, send to your analytics backend)
    try {
      const eventData = {
        event: eventName,
        properties: {
          ...properties,
          timestamp: new Date().toISOString(),
          url: window.location.href,
        },
      };
      
      const stored = localStorage.getItem('analytics_events');
      const events = stored ? JSON.parse(stored) : [];
      events.push(eventData);
      localStorage.setItem('analytics_events', JSON.stringify(events));
      
      // Also send to your analytics endpoint in production
      // fetch('/api/analytics', { ... })
    } catch (error) {
      console.error('Analytics tracking error:', error);
    }
  }
};

export const trackPageView = (pageName: string) => {
  trackEvent('page_view', { page: pageName });
};

export const trackResortClick = (resortName: string, resortLocation: string, surveyUrl: string) => {
  trackEvent('resort_upgrade_click', {
    resort_name: resortName,
    resort_location: resortLocation,
    survey_url: surveyUrl,
  });
};

export const trackScrollToResorts = () => {
  trackEvent('scroll_to_resorts_click');
};

