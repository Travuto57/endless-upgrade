# Booksi Upgrade Landing Page - Deployment Instructions

## Project Overview
This is a React-based landing page for Booksi resort upgrade offers with analytics tracking.

## Prerequisites
- Node.js 18+ and pnpm installed
- A web hosting service (Vercel, Netlify, AWS, etc.)

## Local Development

1. **Extract the zip file** and navigate to the project directory:
   ```bash
   cd booksi-upgrade-landing
   ```

2. **Install dependencies**:
   ```bash
   pnpm install
   ```

3. **Run the development server**:
   ```bash
   pnpm dev
   ```
   The site will be available at `http://localhost:3000`

## Building for Production

1. **Build the project**:
   ```bash
   pnpm build
   ```
   This creates optimized production files in the `dist` directory.

2. **Preview the production build locally**:
   ```bash
   pnpm preview
   ```

## Deployment Options

### Option 1: Vercel (Recommended)
1. Install Vercel CLI: `npm i -g vercel`
2. Run `vercel` in the project directory
3. Follow the prompts to deploy

### Option 2: Netlify
1. Install Netlify CLI: `npm i -g netlify-cli`
2. Run `netlify deploy --prod`
3. Point to the `dist` directory when prompted

### Option 3: Static Hosting (AWS S3, GitHub Pages, etc.)
1. Build the project: `pnpm build`
2. Upload the contents of the `dist` directory to your hosting service
3. Configure your hosting to serve `index.html` for all routes (SPA routing)

## Environment Variables
The project uses these built-in environment variables (already configured):
- `VITE_APP_TITLE`: "Booksi Resort Upgrade"
- `VITE_APP_LOGO`: Logo URL (if needed)

## Analytics Dashboard
- Access the analytics dashboard at `/analytics`
- Currently stores data in localStorage (client-side only)
- For production, integrate with your analytics backend by modifying `client/src/lib/analytics.ts`

## Resort Survey URLs
The following survey URLs are configured:
- **Hyatt Vivid Grand Island**: https://access.booksi.com/hyatt-vivid-grand-island-survey-3
- **Dreams Los Cabos**: https://access.booksi.com/ultra-luxury-cabo-resort-nm-survey-3
- **Secrets Vallarta Bay**: https://access.booksi.com/ultra-adult-luxury-puerto-vallarta-survey-3
- **Breathless Punta Cana**: https://access.booksi.com/luxury-adult-punta-cana-survey-3

## Customization

### Update Resort Information
Edit `client/src/pages/Home.tsx` - modify the `resorts` array

### Update Images
Replace images in `client/public/` directory

### Modify Analytics
Edit `client/src/lib/analytics.ts` to integrate with your analytics service

### Styling
- Global styles: `client/src/index.css`
- Tailwind config: `tailwind.config.ts`

## Support
For issues or questions, refer to the project documentation or contact the development team.

## Tech Stack
- **Framework**: React 19 + Vite
- **Styling**: Tailwind CSS 4
- **UI Components**: shadcn/ui
- **Routing**: Wouter
- **Carousel**: Embla Carousel
- **Package Manager**: pnpm

